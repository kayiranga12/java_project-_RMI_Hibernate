/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Service.Implementation.CriminalinfoImpl;
import Service.Implementation.PoliceinfoImpl;
import Service.Implementation.UserImpl;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

/**
 *
 * @author Admin
 */
public class Server{
    
    
    public static void main(String[] args) {
        try {
            
            System.setProperty("java.rmi.server.hostname", "127.0.0.1");
            Registry registry = LocateRegistry.createRegistry(7000);
            

            registry.rebind("user", new UserImpl());
            registry.rebind("criminal", new CriminalinfoImpl());
            registry.rebind("police", new PoliceinfoImpl());
            
            System.out.println("Running on port 7000");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}