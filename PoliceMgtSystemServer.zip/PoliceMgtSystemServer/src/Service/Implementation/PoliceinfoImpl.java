/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service.Implementation;

import Dao.PoliceinfoDao;
import Model.Policeinfo;
import Service.PoliceinfoInterface;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;
/**
 *
 * @author Kayiranga
 */
public class PoliceinfoImpl extends UnicastRemoteObject implements PoliceinfoInterface{
        public PoliceinfoImpl() throws RemoteException{
        super();
        }
     public PoliceinfoDao dao = new PoliceinfoDao();
    @Override
    public String registerpoliceinfo(Policeinfo policeinfo) throws RemoteException {
      return dao.registerPoliceinfo(policeinfo);
    }

    @Override
    public String updatepoliceinfo(Policeinfo policeinfo) throws RemoteException {
    return dao.updatePoliceinfo(policeinfo);
    }

    @Override
    public String deletepoliceinfo(Policeinfo policeinfo) throws RemoteException {
     return dao.deletePoliceinfo(policeinfo);
    }

    @Override
    public List<Policeinfo> getallpoliceinfo() throws RemoteException {
      return dao.getallpoliceinfo();
    }

    @Override
    public Policeinfo getPoliceinfo(Policeinfo policeinfo) throws RemoteException {
        return dao.getpoliceinfobyid(policeinfo);
    }

    
    
}
