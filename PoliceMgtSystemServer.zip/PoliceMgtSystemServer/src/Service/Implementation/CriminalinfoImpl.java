
package Service.Implementation;

import Dao.CriminalinfoDao;
import Model.Criminalinfo;
import Service.CriminalinfoInterface;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.List;

/**
 *
 * @author Kayiranga
 */
public class CriminalinfoImpl extends UnicastRemoteObject implements CriminalinfoInterface{
        public CriminalinfoImpl() throws RemoteException{
        super();
        }
    
    public CriminalinfoDao dao =  new CriminalinfoDao();

    @Override
    public String registercriminalinfo(Criminalinfo criminalinfo) throws RemoteException {
     return dao.registerPoliceinfo(criminalinfo);
    }

    @Override
    public String updatecriminalinfo(Criminalinfo criminalinfo) throws RemoteException {
      return dao.updatecriminalinfo(criminalinfo);
    }

    @Override
    public String deletecriminalinfo(Criminalinfo criminalinfo) throws RemoteException {
       return dao.deletecriminalinfo(criminalinfo);
    }

    @Override
    public List<Criminalinfo> getallcriminalinfo() throws RemoteException {
        return dao.getallcriminalinfo();
    }

    @Override
    public Criminalinfo getcriminalinfobyid(Criminalinfo criminalinfo) throws RemoteException {
        return dao.getcriminalinfobyid(criminalinfo);
    }
    
}
