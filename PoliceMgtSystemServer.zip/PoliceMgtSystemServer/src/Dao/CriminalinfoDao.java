/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.Criminalinfo;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.Transaction;


/**
 *
 * @author Kayiranga
 */
public class CriminalinfoDao {
    
    //create
    public String registerPoliceinfo(Criminalinfo criminalinfo){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.save(criminalinfo);
        tr.commit();
        ss.close();
        return "data saved successful";
    }
            //update
    public String updatecriminalinfo(Criminalinfo criminalinfo){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.update(criminalinfo);
        tr.commit();
        ss.close();
        return "data updated successful";
    }
    
        public String deletecriminalinfo(Criminalinfo criminalinfo){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.delete(criminalinfo);
        tr.commit();
        ss.close();
        return "data deleted successful";
    }
            //read data from db
    public List<Criminalinfo> getallcriminalinfo(){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Criminalinfo> criminalinfolist = ss.createQuery("select cr from Criminalinfo cr").list();
        ss.close();
        return criminalinfolist;
    }
    //search police info by id
    
    public Criminalinfo getcriminalinfobyid(Criminalinfo criminalinfo){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Criminalinfo cr = (Criminalinfo)ss.get(Criminalinfo.class, criminalinfo.getId());
        ss.close();
        return cr;
    }
    }
