
package Dao;

import Model.Policeinfo;
import java.util.List;
import org.hibernate.Session;
import org.hibernate.*;

/**
 *
 * @author Kayiranga
 */
public class PoliceinfoDao {
    
    //create
    public String registerPoliceinfo(Policeinfo policeinfo){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.save(policeinfo);
        tr.commit();
        ss.close();
        return "data saved successful";
    }
        //update
    public String updatePoliceinfo(Policeinfo policeinfo){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.update(policeinfo);
        tr.commit();
        ss.close();
        return "data updated successful";
    }
           
       //delete
    public String deletePoliceinfo(Policeinfo policeinfo){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.delete(policeinfo);
        tr.commit();
        ss.close();
        return "data deleted successful";
    }
    //read data from db
    public List<Policeinfo> getallpoliceinfo(){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<Policeinfo> policeinfolist = ss.createQuery("select pol from Policeinfo pol").list();
        ss.close();
        return policeinfolist;
    }
    //search police info by id
    
    public Policeinfo getpoliceinfobyid(Policeinfo policeinfo){
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Policeinfo pol = (Policeinfo)ss.get(Policeinfo.class, policeinfo.getId());
        ss.close();
        return pol;
    }
    }
