/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Dao;

import Model.User;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Admin
 */
public class UserDao {
    
    public String newuser(User user){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.save(user);
        tr.commit();
        
        ss.close();
        return "saved";
        
    }
    public String updateuser(User user){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.update(user);
        tr.commit();
        
        ss.close();
        return "updated";
        
    }
    public String deleteuser(User user){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        Transaction tr = ss.beginTransaction();
        
        ss.delete(user);
        tr.commit();
        
        ss.close();
        return "delete";
        
    }
    public List<User> allUsers(){
     
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<User> users = ss.createQuery("select us from User us").list();
        ss.close();
        return users;
        
    }
    public List<User> Login(String username, String password){
        
        Session ss = HibernateUtil.getSessionFactory().openSession();
        List<User> userlist = null;
        try {
            
            Query query = ss.createQuery("select user from User user where user.username = :username and user.password = :password");
            query.setParameter("username", username);
            query.setParameter("password", password);
            
            userlist = query.list();
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            ss.close();
        }
       return userlist;
    }
}
