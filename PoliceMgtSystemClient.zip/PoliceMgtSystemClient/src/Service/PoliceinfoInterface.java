/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Service;

import Model.Policeinfo;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.List;

/**
 *
 * @author Kayiranga
 */
public interface PoliceinfoInterface extends Remote{

    public String registerpoliceinfo(Policeinfo policeinfo) throws RemoteException;

    public String updatepoliceinfo(Policeinfo policeinfo) throws RemoteException;

    public String deletepoliceinfo(Policeinfo policeinfo) throws RemoteException;

    public List<Policeinfo> getallpoliceinfo() throws RemoteException;
    
     public Policeinfo getPoliceinfo(Policeinfo policeinfo) throws  RemoteException;

}
