/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Model;

import java.io.Serializable;
import javax.swing.ImageIcon;

/**
 *
 * @author Kayiranga
 */
public class Policeinfo implements Serializable{
    private static final long serialVersionUID = 1L;
    private Integer id;
    private String FirstName;
    private String LastName;
    private String Age;
    private String Gender;
    private String Date;
    private String phone;
    private String Designation;
    private String Living;
    private String Permanent;
    private String Email;
    private String NID;
    private String District;
    private String jd;
    private String rd;
    private String PoliceStation;
    private String Salary;
   // private byte[] photo;
 
    public Policeinfo() {
    }

    

    public Policeinfo(Integer id, String FirstName, String LastName, String Age, String Gender, String Date, String phone, String Designation, String Living, String Permanent, String Email, String NID, String District, String jd, String rd, String PoliceStation, String Salary) {
        this.id = id;
        this.FirstName = FirstName;
        this.LastName = LastName;
        this.Age = Age;
        this.Gender = Gender;
        this.Date = Date;
        this.phone = phone;
        this.Designation = Designation;
        this.Living = Living;
        this.Permanent = Permanent;
        this.Email = Email;
        this.NID = NID;
        this.District = District;
        this.jd = jd;
        this.rd = rd;
        this.PoliceStation = PoliceStation;
        this.Salary = Salary;
    }


    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getFirstName() {
        return FirstName;
    }

    public void setFirstName(String FirstName) {
        this.FirstName = FirstName;
    }

    public String getLastName() {
        return LastName;
    }

    public void setLastName(String LastName) {
        this.LastName = LastName;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String Age) {
        this.Age = Age;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String Date) {
        this.Date = Date;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String Designation) {
        this.Designation = Designation;
    }

    public String getLiving() {
        return Living;
    }

    public void setLiving(String Living) {
        this.Living = Living;
    }

    public String getPermanent() {
        return Permanent;
    }

    public void setPermanent(String Permanent) {
        this.Permanent = Permanent;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getNID() {
        return NID;
    }

    public void setNID(String NID) {
        this.NID = NID;
    }

    public String getDistrict() {
        return District;
    }

    public void setDistrict(String District) {
        this.District = District;
    }

    public String getJd() {
        return jd;
    }

    public void setJd(String jd) {
        this.jd = jd;
    }

    public String getRd() {
        return rd;
    }

    public void setRd(String rd) {
        this.rd = rd;
    }

    public String getPoliceStation() {
        return PoliceStation;
    }

    public void setPoliceStation(String PoliceStation) {
        this.PoliceStation = PoliceStation;
    }

    public String getSalary() {
        return Salary;
    }

    public void setSalary(String Salary) {
        this.Salary = Salary;
    }

}
